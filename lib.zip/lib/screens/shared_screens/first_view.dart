import 'package:flutter/material.dart';
import 'package:nAndBooking/screens/shared_screens/dashboard.dart';
import 'package:nAndBooking/support_widget/app_font_styling.dart';

class FirstView extends StatefulWidget {
  @override
  _FirstViewState createState() => _FirstViewState();
}

class _FirstViewState extends State<FirstView> {
  @override
  Widget build(BuildContext context) {
    var ht = MediaQuery.of(context).size.height;
    var wt = MediaQuery.of(context).size.width;
    return Scaffold(
        body: Container(
      width: wt,
      height: ht,
      color: Colors.white,
      child: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text('N&B Booking', style: fontStyle(48, Colors.black)),
            SizedBox(height: 5),
            Text(
              'A service booking app',
              style: TextStyle(color: Colors.grey[400], fontSize: 15),
            ),

            SizedBox(height: 50),
            //place for image
            CircleAvatar(
              radius: 80,
              backgroundColor: Colors.transparent,
              // backgroundImage: AssetImage(''),
            ),
            SizedBox(height: 150),
            Container(
              width: wt / 2,
              height: ht * 0.05,
              child: RaisedButton(
                color: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
                elevation: 5.0,
                onPressed: () {
                  Navigator.of(context).pushReplacement(
                      MaterialPageRoute(builder: (context) => DashBoard()));
                  // return showDialog(
                  //   barrierDismissible: true,
                  //   context: context,
                  //   builder: (BuildContext context) => CustomDialog(
                  //       title: 'Login with Ayur Sadan',
                  //       description:
                  //           'You can either use your google a/c or your AyurSadan account. ',
                  //       primaryBtnRoute: '/userLogin',
                  //       primaryBtnTxt: 'With AyurSadan',
                  //       secBtnRoute: '/google',
                  //       secBtnTxt: 'With Google'),
                  // );
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.chevron_right,
                      size: 28,
                    ),
                    Text(
                      'Let\'s Get Started',
                      style: TextStyle(color: Colors.black),
                      // style: styling(22, ColorPalette().highlightColor),
                    ),
                  ],
                ),
              ),
            ),

            TextButton(
              onPressed: () {
                // showDialog(
                //   context: context,
                //   builder: (BuildContext context) => CustomDialog(
                //       title: 'Join with Ayur Sadan',
                //       description:
                //           'By creating an account, you will be able to gain access to the features of this app. All your datas and records like profile info and settings will also be secured and saved as well. ',
                //       primaryBtnRoute: '/addUser',
                //       primaryBtnTxt: 'Create My Account',
                //       secBtnRoute: '',
                //       secBtnTxt: 'Maybe Later'),
                // );
              },
              child: Text(
                '  Or, Sign up with new account',
                style: TextStyle(color: Colors.grey[400]),
              ),
            ),
            // Container(
            //     width: wt / 2,
            //     child: RaisedButton(
            //       onPressed: () {},
            //       child: Text('Continue ...'),
            //     ))
          ],
        ),
      ),
    ));
  }
}
